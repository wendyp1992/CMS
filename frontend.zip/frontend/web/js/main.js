$(document).ready(function () {
    $(document).ready(function () {
        $('.carousel').carousel();
    });
});